package prob0719;

public class NonUnaryInstr extends ACode{
    private final Mnemon mnemonic;
    private final AArg oprndSpec;
    private final Mnemon addrMode;
    String output = "";

    public NonUnaryInstr(Mnemon mn, AArg oArg, Mnemon aArg) {
        mnemonic = mn;
        oprndSpec = oArg;
        addrMode = aArg;
    }
    @Override
    public String generateListing() {
        return String.format("%s" + "%s" + "%s\n",
                Maps.mnemonStringTable.get(mnemonic),
                oprndSpec.generateListing(),
                Maps.mnemonStringTable.get(addrMode));
    }
    @Override
    public String generateCode() {
        switch (mnemonic) {
            case M_BR:
                output = Util.intToHex(Maps.mnemonDeciTable.get(mnemonic) + Maps.mnemonAddrTable.get(addrMode));
                output += oprndSpec.generateCode();
                return output;
            case M_BRLT:
                output = Util.intToHex(Maps.mnemonDeciTable.get(mnemonic) + Maps.mnemonAddrTable.get(addrMode));
                output += oprndSpec.generateCode();
                return output;
            case M_BRLE:
                output = Util.intToHex(Maps.mnemonDeciTable.get(mnemonic) + Maps.mnemonAddrTable.get(addrMode));
                output += oprndSpec.generateCode();
                return output;
            case M_BREQ:
                output = Util.intToHex(Maps.mnemonDeciTable.get(mnemonic) + Maps.mnemonAddrTable.get(addrMode));
                output += oprndSpec.generateCode();
                return output;
            case M_CPWA:
                output = Util.intToHex(Maps.mnemonDeciTable.get(mnemonic) + Maps.mnemonAddrTable.get(addrMode));
                output += oprndSpec.generateCode();
                return output;
            case M_DECI:
                output = Util.intToHex(Maps.mnemonDeciTable.get(mnemonic) + Maps.mnemonAddrTable.get(addrMode));
                output += oprndSpec.generateCode();
                return output;
            case M_DECO:
                output = Util.intToHex(Maps.mnemonDeciTable.get(mnemonic) + Maps.mnemonAddrTable.get(addrMode));
                output += oprndSpec.generateCode();
                return output;
            case M_ADDA:
                output = Util.intToHex(Maps.mnemonDeciTable.get(mnemonic) + Maps.mnemonAddrTable.get(addrMode));
                output += oprndSpec.generateCode();
                return output;
            case M_SUBA:
                output = Util.intToHex(Maps.mnemonDeciTable.get(mnemonic) + Maps.mnemonAddrTable.get(addrMode));
                output += oprndSpec.generateCode();
                return output;
            case M_LDWA:
                output = Util.intToHex(Maps.mnemonDeciTable.get(mnemonic) + Maps.mnemonAddrTable.get(addrMode));
                output += oprndSpec.generateCode();
                return output;
            case M_STWA:
                output = Util.intToHex(Maps.mnemonDeciTable.get(mnemonic) + Maps.mnemonAddrTable.get(addrMode));
                output += oprndSpec.generateCode();
                return output;
            default:
                return ""; // Should not occur.
        }
    }
}
