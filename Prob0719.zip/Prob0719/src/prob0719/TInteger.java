package prob0719;

public class TInteger extends Token{
    private final int intValue;

    public TInteger(int i){
        intValue = i;
    }

    @Override
    public String getDescription(){ return ""; }

    @Override
    public int getValue(){
        return intValue;
    }
}
