package prob0719;

abstract public class AArg {
    abstract public String generateListing();
    abstract public String generateCode();
    abstract public int getIntValue();
}
