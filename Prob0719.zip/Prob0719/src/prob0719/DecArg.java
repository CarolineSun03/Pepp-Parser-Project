package prob0719;

public class DecArg extends AArg{
    private final int intValue;
    public DecArg(int i) {
        intValue = i;
    }
    @Override
    public String generateListing() {
        return String.format("%d", intValue);
    }
    @Override
    public String generateCode(){
        return Util.opToHex(intValue);
    }
    @Override
    public int getIntValue() { return intValue; }
}
