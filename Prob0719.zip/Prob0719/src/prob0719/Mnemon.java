package prob0719;

public enum Mnemon {
    M_BR, M_BRLT, M_BREQ, M_BRLE, M_CPWA, M_DECI, M_DECO, M_ADDA, M_SUBA, M_STWA, M_LDWA,
    M_STOP, M_ASLA, M_ASRA,
    M_BLOCK, M_END,
    M_i, M_d, M_n, M_s, M_sf, M_x, M_sx, M_sfx, M_X
}
