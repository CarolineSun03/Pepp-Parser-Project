package prob0719;

abstract public class ACode {
    abstract public String generateCode();
    abstract public String generateListing();
}
