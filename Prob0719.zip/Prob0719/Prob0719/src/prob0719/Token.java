package prob0719;

abstract class Token {
    public abstract String getDescription();
    public abstract int getValue();

}
