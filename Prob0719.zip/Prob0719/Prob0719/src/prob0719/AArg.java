package prob0719;

abstract public class AArg {
    abstract public String generateCode();
}
